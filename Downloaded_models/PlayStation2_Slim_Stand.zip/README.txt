                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1606616
PlayStation2 Slim Stand by xenomachina is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

While lying horizontally the PlayStation 2 slim takes up a lot more space than it has to. The PS2 is designed to also stand vertically (the logo even rotates!), but it needs a stand to hold it up.

All of the stands I could find selling online were either designed for a different revision of the PS2 slim than mine (which lacks a screw hole) or they cover the vent holes or both. After my original PS3 cooked itself to death I'm a bit paranoid about cooling, so I wanted a stand that would not only work with my PS2, but which would also allow airflow to the bottom vent.

Features of this design:

- Easily printable -- there are absolutely no overhangs.
- Doesn't use too much material (or printing time).
- Provides good ventilation.
- Provides adequate support for the PS2 so it won't tip over.
- Matches the look of the PS2.