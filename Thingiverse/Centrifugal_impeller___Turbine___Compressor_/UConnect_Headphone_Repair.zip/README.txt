                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1699755
UConnect Headphone Repair by firthlink is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

So, somehow the kids have managed to break 3 out of 4 of the battery compartments on the UConnect headphones in our van.  After a few different tries, I was able to settle on this as a solution.  It sort of pressure-fits around the headphone to keep the broken battery door closed.  Pretty cheap to print and no supports needed.  My first ones were out of PLA but they didn't hold up to the crazy heat inside the van on a hot summer day. (It gets over 110 here on a regular basis). The next ones out of ABS are holding up fine though.
It's not perfect, but it's the limit of my skills in Tinkercad.  Wish I knew how to do more. Hopefully it'll help someone else though.

# Print Settings

Printer: Monoprice I3 Clone
Rafts: No
Supports: No
Resolution: .2
Infill: 40